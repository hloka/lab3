const millimeterEl = document.querySelector("#miles");
const kilometerEl = document.querySelector("#kilometer");

function miles(value) {
	kilometerEl.value = value / 0.62137;
}
function kilometer(value) {
	millimeterEl.value = value * 0.62137;
	
}

const kgEl = document.querySelector("#kg");
const poundsEl = document.querySelector("#pounds");

function kg(value) {
	poundsEl.value = value * 2.2;
}
function pounds(value) {
	kgEl.value = value / 2.2;
	
}


const FahrenheitEl = document.querySelector("#Fahrenheit");
const CelsiusEl = document.querySelector("#Celsius");

function Fahrenheit(value) {
	CelsiusEl.value = (value -32.0)*5.0/9.0;
}
function Celsius(value) {
	FahrenheitEl.value =(value*9.0/5.0)+32;
	
}